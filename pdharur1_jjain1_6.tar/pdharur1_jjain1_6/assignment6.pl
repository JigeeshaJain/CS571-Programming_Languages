max([X],X).
max([X|L],X) :- max(L,Res), X > Res.
max([X|L],Res) :- max(L,Res), X =< Res.

sum_even([],0).
sum_even([_],0).
sum_even([_,B],B).
sum_even([_,Y,H|T],Res):-sum_even([H|T],Res1),Res is Y+Res1.

delete_first_k(_, _, [], []).
delete_first_k(_, 0, [H|T], [H|T]).
delete_first_k(X, K, [H|T], Res) :- X == H, K1 is K - 1, delete_first_k(X, K1, T, Res).
delete_first_k(X, K, [H|T], Res) :- X \== H, delete_first_k(X, K, T, Res1),Res = [H|Res1].
